package ejercicio4;

public class Franja {

	private int inicio;
	private int fin;
	private double costeFranja;
	
	
}
