package ejercicio4;

public class Central {

	
	
}
